# CMCHIS Online Application - Android Test App

This Android project wraps the current CMCHIS GitHub Pages test website.

Start URL:
https://gunasekaran1969.github.io/CMCHIS/login.html

The app uses the existing website and Firebase backend. It is intended for testing only.

To build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select the `app` configuration.
4. Build > Build APK(s).
5. Install the generated debug APK on an Android phone.

Do not use real Aadhaar, medical, or other sensitive information while the website is in test mode.
